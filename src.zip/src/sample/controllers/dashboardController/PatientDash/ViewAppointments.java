package sample.controllers.dashboardController.PatientDash;

public class ViewAppointments {
}
