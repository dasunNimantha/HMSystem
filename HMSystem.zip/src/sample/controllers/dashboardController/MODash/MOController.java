package sample.controllers.dashboardController.MODash;

import com.jfoenix.controls.JFXButton;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.layout.BorderPane;

public class MOController {

    @FXML
    private JFXButton recepBtn1;

    @FXML
    private JFXButton recepBtn2;

    @FXML
    private JFXButton recepBtn3;

    @FXML
    private JFXButton recepBtn4;

    @FXML
    private JFXButton recepBtn5;

    @FXML
    private JFXButton recepBtn6;

    @FXML
    private BorderPane recepBorderPane;

    @FXML
    void step1(ActionEvent event) {

    }

    @FXML
    void step2(ActionEvent event) {

    }

    @FXML
    void step3(ActionEvent event) {

    }

    @FXML
    void step4(ActionEvent event) {

    }

    @FXML
    void step5(ActionEvent event) {

    }

    @FXML
    void step6(ActionEvent event) {

    }

    @FXML
    void step7(ActionEvent event) {

    }

}
