package sample.models;

public class UserCreation {
}
