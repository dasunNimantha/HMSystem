package sample.models;

public class Admin {
}
